#!/bin/bash


echo "start !!!"

cd ./crashLog

export DEVELOPER_DIR="/Applications/XCode.app/Contents/Developer"

for file in ./*
do
		if test -f $file
		then
            if [ ! -f ../symbolicatecrashLog/$file ] ; then
                echo "------- symbolicatecrash file = "$file
                for dsym in ../build/*
                do
                	echo "dsym is $dsym"
                	echo "try symbolicate with dsym file: $dsym"
                	/Applications/Xcode.app/Contents/SharedFrameworks/DVTFoundation.framework/Versions/A/Resources/symbolicatecrash $file "$dsym" >> ../symbolicatecrashLog/$file
                	echo "try symbolicate end"
                    open -a TextEdit ../symbolicatecrashLog/$file
                done
			else
				echo "忽略，已经存在./symbolicatecrashLog/$file"
			fi	
		fi
done


echo "end !!!"
