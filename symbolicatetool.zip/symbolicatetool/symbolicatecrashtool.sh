#!/bin/bash


echo "start !!!"

cd ~/Documents/crash/crashLog

#rm -rf ~/Documents/crash/symbolicatecrashLog
#mkdir ~/Documents/crash/symbolicatecrashLog

export DEVELOPER_DIR="/Applications/XCode.app/Contents/Developer"
for file in ./*
do
		if test -f $file
		then
                        if [ ! -f ../symbolicatecrashLog/$file ] ; then
				echo "------- symbolicatecrash file = "$file

                		export uuid="$(cat $file | grep "slice_uuid" | sed 's/^.*slice_uuid":"//g' | sed 's/","build_version".*$//g')";
       		        	export dSYMPath="$(find ../build -iname '*.dSYM' -print0 | xargs -0 dwarfdump -u  | grep uuid | sed -E 's/^[^/]+//' | head -n 1)";

                		/Applications/Xcode.app/Contents/SharedFrameworks/DVTFoundation.framework/Versions/A/Resources/symbolicatecrash $file "$dSYMPath" >> ../symbolicatecrashLog/$file
			else
				echo "忽略，已经存在./symbolicatecrashLog/$file"
			fi	
		fi
done


echo "end !!!"
